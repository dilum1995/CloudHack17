angular.module('starter.services', [])

.factory('Chats', function($http) {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var chats;
  $http.get("http://ch.tantalize.lk/api/products/all").then(function(response){
      chats = response.data;
      console.log(chats);
  })
  return {
    all: function() {
      //return chats;

      $http.get("http://ch.tantalize.lk/api/products/all").then(function(response){
      chats = response.data;
      console.log(chats);
      return chats;
      })


    },
    remove: function(chat) {
      chats.splice(chats.indexOf(chat), 1);
    },
    get: function(chatId) {
      for (var i = 0; i < chats.length; i++) {
        if (chats[i].id === parseInt(chatId)) {
          return chats[i];
        }
      }
      return null;
    }
  };
});
