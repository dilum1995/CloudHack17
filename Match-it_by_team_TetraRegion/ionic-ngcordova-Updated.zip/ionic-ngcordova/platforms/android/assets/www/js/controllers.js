var app=angular.module('starter.controllers', [])

app.controller('DashCtrl', function($scope) {})

app.controller('ChatsCtrl', function($scope, Chats,$http) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});
 $http.get("http://ch.tantalize.lk/api/products/all").then(function(response){
      $scope.chats = response.data;
      //console.log(chats);
      
  })
  //$scope.chats = Chats.all();
  console.log($scope.chats)
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };
})

app.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
  console.log($scope.chat);
})

app.controller('DashzCtrl', function($scope) {
  
});

app.controller("SearchController",function($scope,$http){

  $scope.productData = JSON.parse(localStorage.getItem("imageData"));
  $scope.dataResults = true;
  localStorage.removeItem("imageData")
  if(!$scope.productData.product){
    $scope.dataResults =false;
  }





});

app.controller('CameraCtrl',function($scope, $cordovaCamera, $location, $cordovaImagePicker,$http,$window){
  $scope.baseImage = "";
  $scope.testme ="this is a test"
  $scope.takePicture= function(){
    var options={
      destinationType: Camera.DestinationType.DATA_URL,
      encodingType: Camera.EncodingType.JPEG,
      sourceType: Camera.PictureSourceType.CAMERA,
      sourceType: Camera.PictureSourceType.CAMERA,
      saveToPhotoAlbum: true,
    }

    $cordovaCamera.getPicture(options).then(function(data){
      console.log('camera data: '+ angular.toJson(data));
      $scope.picURL='data:image/jpeg;base64,'+data;
      $scope.baseImage = data;
      
      
      //return;
      
    }, function(error){
      console.log('camera error: '+ angular.toJson(data));
    })
  }

  $scope.searchPicture=function(){
    // //$location.path("/test");
       
    // console.log("yolo")
    var link  = "http://ch.tantalize.lk/api/search"
             

    $http.post(link,{base:$scope.baseImage}).then(function(res){

          $scope.testResponse = res;
          $scope.testUrl = res;
          localStorage.clear();
          localStorage.setItem("imageData",JSON.stringify(res.data))
          $window.location.assign("#/testMe");  
      

      });

       
  }

  $scope.addPicture=function(){
    var options = {
    maximumImagesCount: 1,
    width: 100,
    height: 100,
    quality: 80
  };

//   ImagePicker.getPictures(options).then(
//   file_uris => this._navCtrl.push(GalleryPage, {images: file_uris}),
//   err => console.log('uh oh')
// );

  $cordovaImagePicker.getPictures(options)
    .then(function (results) {
      
      
       $scope.picr='results:image/jpg;base64,'+results; 
       $scope.p=results;
       //alert($results)
    }, function(error) {
      // error getting photos
    })
    
   
  }


})


// app.controller('customersCtrl', function($scope, $http) {
//     $http.get("customers.php")
//     .then(function (response) {$scope.names = response.data.records;});
// });
